package com.policy.config;

public class AppConfig {

}
